

const ErrorPage = () => {
    return (
        <div>
            <h2>Error page ...</h2>
        </div>
    );
};

export default ErrorPage;